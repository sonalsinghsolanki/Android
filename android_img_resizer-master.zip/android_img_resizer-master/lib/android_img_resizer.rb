require 'android_img_resizer/version'
require 'android_img_resizer/android_img_resizer'
